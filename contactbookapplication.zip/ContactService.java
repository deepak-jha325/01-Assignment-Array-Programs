package com.ashokit.service;

import java.util.List;

import com.ashokit.dto.Contact;

public interface ContactService {
	
	public List<Contact> getAllContacts();
	
	public Contact getContactById(Integer cid);
	
	public boolean saveContact(Contact contact);
	
	public boolean updateContact(Contact contact);

	public void deleteContact(Integer id);
	

}
