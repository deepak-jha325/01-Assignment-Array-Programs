package com.ashokit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ashokit.dto.Contact;
import com.ashokit.service.ContactService;

@Controller
public class ViewContactController {

	@Autowired
	private ContactService contactService;

	//constructor
	public ViewContactController(ContactService contactService) {		
		this.contactService = contactService;
	}

	@GetMapping("/editContact")
	public String editContactDtls(@RequestParam("id")Integer id, Model model) {
		Contact contactById = contactService.getContactById(id);
		model.addAttribute("contact", contactById);
		return "index";
	}
	
	@GetMapping("/deleteContact")
	public String deleteContact(@RequestParam("id")Integer id) {
		contactService.deleteContact(id);
		return "redirect:/viewSuccessContact";
		
	}
}
