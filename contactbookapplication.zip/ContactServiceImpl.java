package com.ashokit.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ashokit.dto.Contact;
import com.ashokit.entity.ContactDtlsEntity;
import com.ashokit.repository.ContactDtlsRepository;

/**
 * @author ADMIN
 *
 */

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactDtlsRepository contactRepository;
	
	/**
	 * @author ADMIN
	 * This method is used for get all contacts.
	 */

	@Override
	public List<Contact> getAllContacts() {
		List<Contact> contactList = new ArrayList<Contact>();	
		List<ContactDtlsEntity> entitiesList = contactRepository.findAll();
		entitiesList.forEach(entity -> {
			Contact c = new Contact();
			BeanUtils.copyProperties(entity, c);
			contactList.add(c);
		});

		return contactList;
	}
	
	/**
	 * @author ADMIN
	 * This method is used to get contact by id
	 */

	@Override
	public Contact getContactById(Integer id) {
		Optional<ContactDtlsEntity> optional = contactRepository.findById(id);
		if (optional.isPresent()) {
			ContactDtlsEntity entity = optional.get();
			Contact mycontact = new Contact();
			BeanUtils.copyProperties(entity, mycontact);
			return mycontact;
		}
		return null;
	}
	
	/**
	 * @author ADMIN
	 * This method is used to save contact in the database.
	 */

	@Override
	public boolean saveContact(Contact contact) {
		ContactDtlsEntity entity = new ContactDtlsEntity();
		BeanUtils.copyProperties(contact, entity);
		ContactDtlsEntity savedEntity = contactRepository.save(entity);
		return savedEntity.getId() != null;
	}
	
	/**
	 * @author ADMIN
	 * This method is used for edit/update the contact.
	 */

	@Override
	public boolean updateContact(Contact contact) {
		// TODO Auto-generated method stub
		return false;
	}
	
	/**
	 * @author ADMIN
	 * This method is used to delete the contact which take Contact id as a parameter.
	 */
	
	@Override
	public void deleteContact(Integer id) {
		contactRepository.deleteById(id);
	}
	
}
