package com.ashokit.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name ="contact_table")
public class ContactDtlsEntity {

	@Id
	@Column(name = "contact_id")
	@GeneratedValue
	private Integer id;
	@Column(name = "contact_name")
	private String name;
	@Column(name = "contact_email")
	private String email;
	@Column(name = "contact_number")
	private Long num;
	
	
	
	
	
	public ContactDtlsEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public ContactDtlsEntity(String name, String email, Long num) {
		super();
		this.name = name;
		this.email = email;
		this.num = num;
	}


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getNum() {
		return num;
	}
	public void setNum(Long num) {
		this.num = num;
	}
	
	
}
