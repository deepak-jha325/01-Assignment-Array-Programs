package com.ashokit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ashokit.dto.Contact;
import com.ashokit.entity.ContactDtlsEntity;
import com.ashokit.service.ContactService;

/**
 * @author ADMIN
 *
 */

@Controller
public class ContactInfoController {

	@Autowired
	private ContactService contactservice;

	@GetMapping("/dashboard")
	public String contactDashboard() {
		return "dashboard";

	}

	/**
	 * @author ADMIN This method is used to render the Contact Form
	 */
	@GetMapping("/")
	public String loadContactForm(Model model) {
		Contact contactObject = new Contact();
		model.addAttribute("contact", contactObject);
		return "index";
	}

	/**
	 * @author ADMIN This method is used for handling contact form Register Button
	 */
	@PostMapping("/submit")
	public String handleContactDtlsRegister(@ModelAttribute("contact") Contact contact, RedirectAttributes model) {
		boolean isSaved = contactservice.saveContact(contact);
		if (isSaved) {
			model.addFlashAttribute("positive", "Contact saved");
		} else {
			model.addFlashAttribute("negative", "Failed to Save Contact");
		}
		return "redirect:/renderSuccess";
	}

	@GetMapping("/renderSuccess")
	public String redirect(Model model) {
		model.addAttribute("contact", new Contact());
		return "index";
	}

	/**
	 * @author ADMIN This method is used for handling view all contact details Link
	 */

	@GetMapping("/viewSuccessContact")
	public String handleviewallContactDtlsLink(Model model) {
		List<Contact> allContacts = contactservice.getAllContacts();
		model.addAttribute("contact", allContacts);
		return "viewContacts";

	}

}
